<?php
/*
Plugin Name: Affsquare Plugin
Author: Shrief elsakaa
Description: Customization options for the Affsquare theme, including header logo.
Version: 1.0
*/

add_action('wp_head', 'affsquare_custom_logo');

add_action('admin_menu', 'affsquare_add_admin_menu');
add_action('admin_init', 'affsquare_settings_init');
add_action('admin_enqueue_scripts', 'affsquare_enqueue_scripts');


$custom_logo_id = apply_filters('affsquare_custom_logo_id', get_option('affsquare_logo_id'));

function affsquare_custom_logo() {
    global $custom_logo_id;
    if (!empty($custom_logo_id)) {
        echo wp_get_attachment_image($custom_logo_id, 'full', false, array('alt' => 'Affsquare Logo'));
    }
}

function affsquare_add_admin_menu() {
    add_menu_page('Affsquare Logo Settings', 'Affsquare Settings', 'manage_options', 'affsquare_logo_settings', 'affsquare_logo_settings_page');
}

function affsquare_settings_init() {
    register_setting('affsquare_plugin_options', 'affsquare_logo_id', array(
        'type' => 'integer',
        'sanitize_callback' => 'absint'
    ));
    add_settings_section('affsquare_plugin_options_section', 'Logo Settings', 'affsquare_settings_section_callback', 'affsquare_plugin_options');
    add_settings_field('affsquare_logo_id', 'Upload Logo', 'affsquare_logo_id_render', 'affsquare_plugin_options', 'affsquare_plugin_options_section');
}

function affsquare_settings_section_callback() {
    echo 'Upload and select a custom logo for the header.';
}

function affsquare_logo_id_render() {
    $logo_id = get_option('affsquare_logo_id');
    echo '<input type="hidden" name="affsquare_logo_id" id="affsquare_logo_id" value="' . $logo_id . '">';
    echo '<input type="button" value="Upload Logo" class="button-primary" id="upload_logo_button">';
    echo '<div id="logo_preview">';
    if (!empty($logo_id)) {
        echo wp_get_attachment_image($logo_id, 'thumbnail', false, array('alt' => 'Logo Preview'));
    }
    echo '</div>';
}

function affsquare_logo_settings_page() {
    ?>
    <div class="wrap">
        <h1>Affsquare Logo Settings</h1>

        <form method="post" action="options.php">
            <?php
                settings_fields('affsquare_plugin_options');
                do_settings_sections('affsquare_plugin_options');
                submit_button();
            ?>
        </form>
    </div>
    <?php
}

function affsquare_enqueue_scripts($hook) {
    if ($hook == 'toplevel_page_affsquare_logo_settings') {
        wp_enqueue_media();
        wp_enqueue_script('affsquare-media-upload', plugins_url('/js/media-upload.js', __FILE__), array('jquery'), null, true);
    }
}
?>
