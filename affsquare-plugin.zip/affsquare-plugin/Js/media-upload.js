jQuery(document).ready(function($) {
    $('#upload_logo_button').click(function(e) {
        e.preventDefault();

        var custom_uploader = wp.media({
            title: 'Upload Logo',
            button: {
                text: 'Use this Logo'
            },
            multiple: false
        });

        custom_uploader.on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $('#affsquare_logo_id').val(attachment.id);
            $('#logo_preview').html('<img src="' + attachment.sizes.thumbnail.url + '" alt="Logo Preview">');
        });

        custom_uploader.open();
    });
});
