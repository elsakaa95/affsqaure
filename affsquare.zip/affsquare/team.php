<?php
function display_team_members($atts) {
    $atts = shortcode_atts(array(
        'number' => -1,
    ), $atts);

    $args = array(
        'post_type'      => 'team_member',
        'posts_per_page' => $atts['number'],
    );

    $team_members = new WP_Query($args);

    ob_start();

    if ($team_members->have_posts()) {
        echo '<ul>';

        while ($team_members->have_posts()) {
            $team_members->the_post();
            echo '<li>' . get_the_title() . '</li>';
        }

        echo '</ul>';
    } else {
        echo 'No team members found.';
    }

    wp_reset_postdata();

    return ob_get_clean();
}

add_shortcode('team_members', 'display_team_members');
?>