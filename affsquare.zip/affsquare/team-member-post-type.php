<?php 
function register_team_member_post_type() {
    $labels = array(
        'name'               => 'Team Members',
        'singular_name'      => 'Team Member',
        'menu_name'          => 'Team Members',
        'name_admin_bar'     => 'Team Member',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Team Member',
        'new_item'           => 'New Team Member',
        'edit_item'          => 'Edit Team Member',
        'view_item'          => 'View Team Member',
        'all_items'          => 'All Team Members',
        'search_items'       => 'Search Team Members',
        'not_found'          => 'No team members found.',
        'not_found_in_trash' => 'No team members found in Trash.',
        'featured_image'     => 'Poster',
        'set_featured_image' => 'Add Poster'
        
    );
    add_theme_support( 'post-thumbnails' );
    $args = array(
        'show_in_rest' => true,
        'labels'             => $labels,
        'public'             => true,
        'show_ui'            => true,
        'menu_icon'          => 'dashicons-groups',
        'capability_type'    => 'post',
        'has_archive'        => true,
        'menu_position'      => 5,
        'supports'          => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments', 'custom-fields' ), 
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'show_in_rest' => true,

    );

    register_post_type('team_member', $args);
}

add_action('init', 'register_team_member_post_type');
function enqueue_single_team_member_styles() {
    if (is_singular('team_member')) { // Adjust the post type if needed
        wp_enqueue_style('single-team-member-style', get_template_directory_uri() . '/single-team-member.css', array(), '1.0', 'all');
    }
}

add_action('wp_enqueue_scripts', 'enqueue_single_team_member_styles');


?>
