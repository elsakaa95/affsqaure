<footer>
        <p>&copy; <?php echo date('Y'); ?> Affsquare</p>
    </footer>
    <?php    
	wp_footer(); 
?>
</body>
</html>
