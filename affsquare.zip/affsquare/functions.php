<?php

function override_affsquare_custom_logo_url($url) {
    // Replace 'your_custom_logo_url_here' with the desired logo URL
    return 'your_custom_logo_url_here';
}
add_filter('affsquare_custom_logo_url', 'override_affsquare_custom_logo_url');



add_action('after_switch_theme', 'create_page_on_theme_activation');

function create_page_on_theme_activation() {
    // Set the title, template, etc
    $new_page_title = __('Home', 'text-domain'); // Page's title
    $new_page_content = '[team_members]'; // Content goes here
    $new_page_template = ''; // The template to use for the page
    $page_check = get_page_by_title($new_page_title); // Check if the page already exists

    // Store the above data in an array
    $new_page = array(
        'post_type' => 'page',
        'post_title' => $new_page_title,
        'post_content' => $new_page_content,
        'post_status' => 'publish',
        'post_author' => 1,
        'post_name' => 'home'
    );

    // If the page doesn't already exist, create it
    if (!isset($page_check->ID)) {
        $new_page_id = wp_insert_post($new_page);
        if (!empty($new_page_template)) {
            update_post_meta($new_page_id, '_wp_page_template', $new_page_template);
        }
    }

    // Set the newly created page as the front page
    $front_page_id = get_option('page_on_front');
    if (!$front_page_id) {
        update_option('page_on_front', $new_page_id);
        update_option('show_on_front', 'page');
    }
}
include ('team-member-post-type.php');

function display_team_members($atts) {
    $args = array(
        'post_type' => 'team_member',
        'posts_per_page' => -1,
    );

    $team_members = new WP_Query($args);

    $output = '<div class="team-members">';

    if ($team_members->have_posts()) {
        while ($team_members->have_posts()) {
            $team_members->the_post();
            $output .= '<div class="team-member">';
            
            // Display the featured image
            if (has_post_thumbnail()) {
                $output .= '<div class="team-member-image">' . get_the_post_thumbnail(null, 'thumbnail') . '</div>';
            }
            
            // Display the member name
            $output .= '<h3 class="team-member-name">' . get_the_title() . '</h3>';
            
            // Display the short description (excerpt)
            $output .= '<p class="team-member-description">' . get_the_excerpt() . '</p>';

            $output .= '</div>'; // Close team-member div
        }

        wp_reset_postdata();
    } else {
        $output .= 'No team members found.';
    }

    $output .= '</div>'; // Close team-members div

    return $output;
}



add_shortcode('team_members', 'display_team_members');
function display_team_members_shortcode() {
    return do_shortcode('[team_members]'); // Replace [team_members] with your actual shortcode
}
function enqueue_custom_styles() {
    wp_enqueue_style('custom-styles', get_template_directory_uri() . '/asstes/css/custom-styles.css', array(), '1.0', 'all');
}

add_action('wp_enqueue_scripts', 'enqueue_custom_styles');
